URL_SERVICE = "https://7625f8a0-9603-44d6-be1d-a24201d33a10.serverhub.praktikum-services.ru"
DOC_PATH = "/docs/"
ORDER_TRACK = "/api/v1/orders/track"
CREATE_ORDER = "/api/v1/orders"