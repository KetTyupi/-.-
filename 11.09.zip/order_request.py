import data
import main
import requests

# Создание нового заказа
def post_new_order(order_body):
    return requests.post(data.URL_SERVICE + data.ORDER_TRACK, json=order_body, headers=main.headers)

response = post_new_order("track");
print(response.json())

# Сохранение номера заказа

#Получение заказа по треку заказа
def get_receive_order_track(track_body):
    return requests.get(data.URL_SERVICE + data.ORDER_TRACK, json=track_body)

response = get_receive_order_track(main.track_body);
print(response.json())

