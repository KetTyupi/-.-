import order_request
import main


#Тест на возврат ответа 200
def test_receive_order_track():
    response = order_request.get_receive_order_track(main.track_body)
    main.track_body = order_request.post_new_order("track")
    assert response.status_code == 200



